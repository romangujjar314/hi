import PageHeader from "@/components/PageHeader";
import MenuExplorer from "@/components/MenuExplorer";
import { getMenu } from "@/lib/repo";
import { categories } from "@/lib/data";
import { img } from "@/lib/images";
export const metadata = { title: "Menu", description: "Stone baked pizzas, burgers, shawarma, pasta, fries and wings. Prices in PKR. Order online in Dina, Jhelum." };
export default async function MenuPage() {
  const items = await getMenu();
  return (<><PageHeader title="The menu" text="Pizzas from the stone oven, burgers, and fast food favourites." image={img.pizza3} />
    <section className="pb-24"><div className="container-x"><MenuExplorer items={items} categories={categories} /></div></section></>);
}
