import { site } from "@/lib/site";
export default function sitemap() {
  return ["", "/about", "/menu", "/order", "/offers", "/gallery", "/reviews", "/contact"].map((p) => ({ url: site.url + p, lastModified: new Date() }));
}
