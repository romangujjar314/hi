import { NextResponse } from "next/server";
import { createOrder } from "@/lib/repo";

export async function POST(req) {
  try {
    const body = await req.json();
    const { customer, items } = body;
    if (!customer?.name || !customer?.phone || !customer?.address || !Array.isArray(items) || !items.length)
      return NextResponse.json({ error: "Missing name, phone, address or items." }, { status: 400 });
    const order = await createOrder(body);
    return NextResponse.json({ order }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not place order." }, { status: 500 });
  }
}
