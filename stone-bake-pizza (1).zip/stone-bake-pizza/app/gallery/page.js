import PageHeader from "@/components/PageHeader";
import GalleryGrid from "@/components/GalleryGrid";
import { getGallery } from "@/lib/repo";
import { img } from "@/lib/images";
export const metadata = { title: "Gallery", description: "Photos of our pizzas, kitchen, restaurant interior and food preparation." };
export default async function Gallery() {
  const items = await getGallery();
  return (<><PageHeader title="Inside Stone Bake" text="Pizzas, the kitchen, and the room where you will eat them." image={img.kitchen} /><section className="pb-24"><div className="container-x"><GalleryGrid items={items} /></div></section></>);
}
