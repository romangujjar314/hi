import Hero from "@/components/Hero";
import { Featured, WhyUs, ReviewsPreview, OffersPreview, LocationSection } from "@/components/home";
import { getFeatured, getReviews, getOffers } from "@/lib/repo";

export default async function Home() {
  const [featured, reviews, offers] = await Promise.all([getFeatured(), getReviews(), getOffers()]);
  return (<><Hero /><Featured items={featured} /><WhyUs /><OffersPreview items={offers} /><ReviewsPreview items={reviews} /><LocationSection /></>);
}
