import PageHeader from "@/components/PageHeader";
import OrderFlow from "@/components/OrderFlow";
import { img } from "@/lib/images";
export const metadata = { title: "Order Online", description: "Order Stone Bake Pizza online for delivery or pickup in Dina, Jhelum, or send your order on WhatsApp." };
export default function OrderPage() {
  return (<><PageHeader title="Your order" text="Review your cart, add your details and confirm." image={img.pizza2} /><section className="pb-24"><div className="container-x"><OrderFlow /></div></section></>);
}
