import { Poppins, Inter } from "next/font/google";
import "./globals.css";
import { site } from "@/lib/site";
import { CartProvider } from "@/components/CartProvider";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Loader from "@/components/Loader";
import WhatsAppButton from "@/components/WhatsAppButton";

const poppins = Poppins({ subsets: ["latin"], weight: ["500", "600", "700"], variable: "--font-poppins", display: "swap" });
const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });

export const metadata = {
  metadataBase: new URL(site.url),
  title: { default: "Stone Bake Pizza | Stone Baked Pizza & Fast Food in Dina, Jhelum", template: "%s | Stone Bake Pizza" },
  description: site.description,
  keywords: ["pizza in Dina", "Stone Bake Pizza", "fast food Jhelum", "stone baked pizza", "burgers Dina", "pizza delivery Jhelum"],
  openGraph: { type: "website", siteName: site.name, locale: "en_PK", title: "Stone Bake Pizza | Dina, Jhelum", description: site.description, url: site.url, images: [{ url: "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=1200&q=75", width: 1200, height: 630, alt: "Stone Bake Pizza" }] },
  twitter: { card: "summary_large_image", title: "Stone Bake Pizza", description: site.description },
  alternates: { canonical: "/" },
};
export const viewport = { themeColor: "#111111" };

const jsonLd = {
  "@context": "https://schema.org", "@type": "Restaurant", name: site.name, telephone: "+92" + site.phone.slice(1).replace("-", ""),
  servesCuisine: ["Pizza", "Burgers", "Fast Food"], priceRange: "Rs. 250 - Rs. 3000", url: site.url,
  address: { "@type": "PostalAddress", addressLocality: "Dina", addressRegion: "Jhelum, Punjab", addressCountry: "PK" },
};
export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${poppins.variable} ${inter.variable}`}>
      <body>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
        <CartProvider>
          <Loader />
          <Navbar />
          <main>{children}</main>
          <Footer />
          <WhatsAppButton />
        </CartProvider>
      </body>
    </html>
  );
}
