import PageHeader from "@/components/PageHeader";
import ContactForm from "@/components/ContactForm";
import Reveal from "@/components/Reveal";
import { MapEmbed } from "@/components/home";
import { site, waLink } from "@/lib/site";
import { img } from "@/lib/images";
export const metadata = { title: "Contact", description: "Find Stone Bake Pizza in Dina, Jhelum. Call 0325-6120333, message on WhatsApp, or send us a note." };
export default function Contact() {
  return (<><PageHeader title="Find us in Dina" text="Call, message, or just walk in." image={img.interior2} />
    <section className="pb-24"><div className="container-x grid gap-10 lg:grid-cols-2">
      <Reveal><div className="space-y-8">
        <div><h2 className="text-2xl font-bold">{site.name}</h2><p className="mt-2 text-white/70">Dina, Jhelum Pakistan</p><a href={`tel:${site.phone.replace(/-/g, "")}`} className="mt-2 block font-heading text-2xl font-semibold text-ember">{site.phone}</a></div>
        <a href={waLink("Hi Stone Bake Pizza!")} target="_blank" rel="noopener noreferrer" className="btn w-fit bg-[#25D366] text-white hover:brightness-110">Chat on WhatsApp</a>
        <div><h3 className="text-lg font-semibold">Opening hours</h3><ul className="mt-3 max-w-sm space-y-2 text-white/70">{site.hours.map(([d, h]) => <li key={d} className="flex justify-between border-b border-white/10 pb-2"><span>{d}</span><span className="text-white">{h}</span></li>)}</ul></div>
        <div className="h-72 overflow-hidden rounded-3xl ring-1 ring-white/10"><MapEmbed /></div>
      </div></Reveal>
      <Reveal delay={0.1}><ContactForm /></Reveal>
    </div></section></>);
}
