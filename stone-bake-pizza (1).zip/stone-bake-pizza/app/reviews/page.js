import PageHeader from "@/components/PageHeader";
import ReviewCard from "@/components/ReviewCard";
import Stars from "@/components/Stars";
import Reveal from "@/components/Reveal";
import { getReviews } from "@/lib/repo";
import { img } from "@/lib/images";
export const metadata = { title: "Customer Reviews", description: "See what customers say about Stone Bake Pizza in Dina, Jhelum." };
export default async function Reviews() {
  const reviews = await getReviews();
  const avg = (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1);
  return (<><PageHeader title="What customers say" image={img.pizza1} />
    <section className="pb-24"><div className="container-x">
      <Reveal className="mb-10 flex items-center gap-5 rounded-3xl bg-char p-6 ring-1 ring-white/10"><p className="font-heading text-5xl font-bold text-white">{avg}</p><div><Stars n={Math.round(avg)} /><p className="mt-1 text-sm text-white/60">Based on {reviews.length} reviews</p></div></Reveal>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">{reviews.map((r, i) => <Reveal key={r.name} delay={(i % 3) * 0.08}><ReviewCard r={r} /></Reveal>)}</div>
    </div></section></>);
}
