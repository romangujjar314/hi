import PageHeader from "@/components/PageHeader";
import OfferCard from "@/components/OfferCard";
import Reveal from "@/components/Reveal";
import { getOffers } from "@/lib/repo";
import { img } from "@/lib/images";
export const metadata = { title: "Offers & Deals", description: "Family deals, weekend specials, student deals and combo offers at Stone Bake Pizza, Dina." };
export default async function Offers() {
  const offers = await getOffers();
  return (<><PageHeader title="Offers and deals" text="Bigger meals, smaller bills." image={img.pizza5} />
    <section className="pb-24"><div className="container-x grid gap-6 md:grid-cols-2">{offers.map((o, i) => <Reveal key={o.id} delay={(i % 2) * 0.1}><OfferCard o={o} /></Reveal>)}</div></section></>);
}
