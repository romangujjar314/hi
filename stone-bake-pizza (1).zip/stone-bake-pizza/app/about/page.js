import Image from "next/image";
import Link from "next/link";
import PageHeader from "@/components/PageHeader";
import Reveal from "@/components/Reveal";
import { img } from "@/lib/images";
export const metadata = { title: "About Us", description: "The story behind Stone Bake Pizza in Dina, Jhelum: authentic stone-baked flavour and quality ingredients." };
const pillars = [
  ["Our mission", "To make every meal in Dina feel like an occasion, with honest food at a fair price."],
  ["Quality ingredients", "Fresh dough daily, real mozzarella, hand-cut vegetables and chicken marinated in-house."],
  ["Customer satisfaction", "If something is not right, we fix it. Your table or your doorstep, you come first."],
];
export default function About() {
  return (<>
    <PageHeader title="Baked on stone, made with care" text="Stone Bake Pizza brings authentic stone-baked flavors with quality ingredients and a passion for creating memorable food experiences." image={img.interior} />
    <section className="section"><div className="container-x grid items-center gap-14 lg:grid-cols-2">
      <Reveal className="relative aspect-[4/3] overflow-hidden rounded-[2rem]"><Image src={img.interior2} alt="Inside Stone Bake Pizza" fill sizes="(min-width:1024px) 50vw, 100vw" className="object-cover" /></Reveal>
      <Reveal delay={0.1}><h2 className="text-3xl font-bold sm:text-4xl">A simple idea, done properly</h2>
        <p className="mt-5 text-white/70">Real stone ovens hold heat differently. They crisp the base in minutes and keep the crumb soft, which is why we built our kitchen around one.</p>
        <p className="mt-4 text-white/70">From pizzas to zinger burgers and shawarma, everything is made to order and sent out while it is still hot.</p>
        <Link href="/menu" className="btn btn-primary mt-8">Explore the menu</Link></Reveal>
    </div></section>
    <section className="section bg-char pt-20"><div className="container-x grid gap-6 md:grid-cols-3">
      {pillars.map(([t, d], i) => <Reveal key={t} delay={i * 0.1}><div className="h-full rounded-3xl border border-white/10 p-8"><h3 className="text-xl font-semibold text-ember">{t}</h3><p className="mt-3 text-white/65">{d}</p></div></Reveal>)}
    </div></section>
  </>);
}
