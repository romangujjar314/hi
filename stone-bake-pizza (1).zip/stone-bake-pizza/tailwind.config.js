/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: { ink: "#111111", ember: "#E85D04", cream: "#FFF3E0", char: "#1b1a19" },
      fontFamily: {
        heading: ["var(--font-poppins)", "system-ui", "sans-serif"],
        body: ["var(--font-inter)", "system-ui", "sans-serif"],
      },
      keyframes: { spin360: { to: { transform: "rotate(360deg)" } }, glow: { "0%,100%": { opacity: ".5" }, "50%": { opacity: ".9" } } },
      animation: { spinslow: "spin360 22s linear infinite", glow: "glow 4s ease-in-out infinite" },
    },
  },
  plugins: [],
};
