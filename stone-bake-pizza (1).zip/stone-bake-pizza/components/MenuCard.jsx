"use client";
import Image from "next/image";
import { useCart } from "./CartProvider";
import { money } from "@/lib/site";
export default function MenuCard({ item, priority }) {
  const { add } = useCart();
  return (
    <article className="group flex h-full flex-col overflow-hidden rounded-3xl bg-char ring-1 ring-white/10 transition duration-500 hover:-translate-y-1 hover:ring-ember/60">
      <div className="relative aspect-[4/3] overflow-hidden">
        <Image src={item.image} alt={item.name} fill priority={priority} sizes="(min-width:1024px) 33vw, (min-width:640px) 50vw, 100vw" className="object-cover transition duration-700 group-hover:scale-105" />
        {item.tag && <span className="absolute left-4 top-4 rounded-full bg-ember px-3 py-1 text-xs font-semibold text-white">{item.tag}</span>}
      </div>
      <div className="flex flex-1 flex-col p-6">
        <div className="flex items-start justify-between gap-4"><h3 className="text-lg font-semibold">{item.name}</h3><p className="font-heading text-lg font-semibold text-ember">{money(item.price)}</p></div>
        <p className="mt-2 flex-1 text-sm leading-relaxed text-white/60">{item.desc}</p>
        <button onClick={() => add(item)} className="btn btn-ghost mt-5 w-full">Add to order</button>
      </div>
    </article>
  );
}
