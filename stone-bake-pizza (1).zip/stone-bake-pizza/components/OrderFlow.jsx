"use client";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useCart } from "./CartProvider";
import { money, waLink } from "@/lib/site";

const steps = ["Cart", "Your details", "Confirm"];
export default function OrderFlow() {
  const { items, dispatch, subtotal, deliveryFee } = useCart();
  const [step, setStep] = useState(0);
  const [type, setType] = useState("delivery");
  const [c, setC] = useState({ name: "", phone: "", address: "", notes: "" });
  const [state, setState] = useState({ loading: false, error: "", order: null });
  const fee = type === "delivery" && items.length ? deliveryFee : 0;
  const total = subtotal + fee;
  const set = (k) => (e) => setC({ ...c, [k]: e.target.value });
  const valid = c.name.trim() && /^[0-9+\- ]{10,}$/.test(c.phone.trim()) && (type === "pickup" || c.address.trim());
  const payload = () => ({ type, customer: { ...c, address: type === "pickup" ? "Pickup" : c.address }, items: items.map(({ id, name, price, qty }) => ({ id, name, price, qty })), subtotal, fee, total });
  const message = () => `*New order - Stone Bake Pizza*\n${items.map((i) => `${i.qty} x ${i.name} - ${money(i.price * i.qty)}`).join("\n")}\n\nSubtotal: ${money(subtotal)}\n${type === "delivery" ? `Delivery: ${money(fee)}\n` : ""}*Total: ${money(total)}*\n\nName: ${c.name}\nPhone: ${c.phone}\n${type === "delivery" ? `Address: ${c.address}\n` : "Pickup\n"}${c.notes ? `Notes: ${c.notes}` : ""}`;

  async function confirm() {
    setState({ loading: true, error: "", order: null });
    try {
      const r = await fetch("/api/orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload()) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error);
      setState({ loading: false, error: "", order: d.order });
      dispatch({ type: "clear" });
    } catch (e) { setState({ loading: false, error: e.message || "Something went wrong. Try WhatsApp instead.", order: null }); }
  }

  if (state.order) return (
    <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="mx-auto max-w-lg rounded-3xl bg-char p-10 text-center ring-1 ring-white/10">
      <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", delay: 0.15 }} className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-ember text-3xl text-white">✓</motion.div>
      <h2 className="mt-6 text-3xl font-bold">Order placed</h2>
      <p className="mt-3 text-white/70">Your order number is <b className="text-white">{state.order.id}</b>. We will call {c.phone} to confirm.</p>
      <div className="mt-8 flex flex-col gap-3"><a className="btn btn-primary" target="_blank" rel="noopener noreferrer" href={waLink(message())}>Send details on WhatsApp</a><Link href="/menu" className="btn btn-ghost">Order more</Link></div>
    </motion.div>
  );

  if (!items.length) return (
    <div className="mx-auto max-w-md rounded-3xl bg-char p-10 text-center ring-1 ring-white/10">
      <h2 className="text-2xl font-bold">Your cart is empty</h2><p className="mt-3 text-white/60">Pick something from the menu and it will appear here.</p>
      <Link href="/menu" className="btn btn-primary mt-7">Browse the menu</Link>
    </div>
  );

  return (
    <div className="grid gap-8 lg:grid-cols-[1.5fr_1fr]">
      <div>
        <ol className="mb-8 flex gap-2 sm:gap-4">{steps.map((s, i) => (
          <li key={s} className={`flex flex-1 items-center gap-3 border-b-2 pb-3 text-sm font-medium transition ${i <= step ? "border-ember text-white" : "border-white/10 text-white/40"}`}>
            <span className={`grid h-6 w-6 place-items-center rounded-full text-xs ${i <= step ? "bg-ember text-white" : "bg-white/10"}`}>{i + 1}</span><span className="hidden sm:inline">{s}</span></li>))}</ol>
        <AnimatePresence mode="wait">
          <motion.div key={step} initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -24 }} transition={{ duration: 0.3 }}>
            {step === 0 && (
              <ul className="space-y-4">{items.map((i) => (
                <li key={i.id} className="flex items-center gap-4 rounded-2xl bg-char p-3 pr-5 ring-1 ring-white/10">
                  <Image src={i.image} alt="" width={88} height={88} className="h-20 w-20 rounded-xl object-cover" />
                  <div className="flex-1"><p className="font-heading font-semibold text-white">{i.name}</p><p className="text-sm text-white/55">{money(i.price)} each</p>
                    <div className="mt-2 inline-flex items-center rounded-full border border-white/15">
                      <button aria-label={`Decrease ${i.name}`} className="h-8 w-8 text-lg hover:text-ember" onClick={() => dispatch({ type: "qty", id: i.id, d: -1 })}>−</button>
                      <span className="w-8 text-center text-sm text-white" aria-live="polite">{i.qty}</span>
                      <button aria-label={`Increase ${i.name}`} className="h-8 w-8 text-lg hover:text-ember" onClick={() => dispatch({ type: "qty", id: i.id, d: 1 })}>+</button></div></div>
                  <div className="text-right"><p className="font-heading font-semibold text-white">{money(i.price * i.qty)}</p><button onClick={() => dispatch({ type: "remove", id: i.id })} className="mt-2 text-xs text-white/45 hover:text-ember">Remove</button></div>
                </li>))}</ul>)}
            {step === 1 && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">{["delivery", "pickup"].map((t) => <button key={t} onClick={() => setType(t)} className={`rounded-xl border px-4 py-3 font-heading text-sm font-medium capitalize transition ${type === t ? "border-ember bg-ember/15 text-white" : "border-white/10 text-white/60"}`}>{t}</button>)}</div>
                <label className="block text-sm">Full name<input className="field mt-1.5" value={c.name} onChange={set("name")} autoComplete="name" /></label>
                <label className="block text-sm">Phone number<input className="field mt-1.5" type="tel" placeholder="03XX-XXXXXXX" value={c.phone} onChange={set("phone")} autoComplete="tel" /></label>
                {type === "delivery" && <label className="block text-sm">Delivery address<textarea className="field mt-1.5" rows={2} value={c.address} onChange={set("address")} autoComplete="street-address" /></label>}
                <label className="block text-sm">Notes (optional)<input className="field mt-1.5" placeholder="Extra spicy, no onions..." value={c.notes} onChange={set("notes")} /></label>
              </div>)}
            {step === 2 && (
              <div className="space-y-4 rounded-2xl bg-char p-6 ring-1 ring-white/10">
                <p className="font-heading text-lg font-semibold text-white">Check your order</p>
                <ul className="space-y-1 text-white/70">{items.map((i) => <li key={i.id} className="flex justify-between"><span>{i.qty} × {i.name}</span><span>{money(i.price * i.qty)}</span></li>)}</ul>
                <hr className="border-white/10" />
                <p className="text-white/70"><b className="text-white">{c.name}</b> · {c.phone}<br />{type === "pickup" ? "Pickup from the restaurant" : c.address}</p>
                <p className="text-sm text-white/45">Payment is cash on delivery or at pickup.</p>
                {state.error && <p role="alert" className="rounded-lg bg-red-500/15 p-3 text-sm text-red-300">{state.error}</p>}
              </div>)}
          </motion.div>
        </AnimatePresence>
      </div>
      <aside className="h-fit rounded-3xl bg-char p-6 ring-1 ring-white/10 lg:sticky lg:top-28">
        <h2 className="text-xl font-bold">Summary</h2>
        <dl className="mt-5 space-y-2 text-white/70"><div className="flex justify-between"><dt>Subtotal</dt><dd>{money(subtotal)}</dd></div><div className="flex justify-between"><dt>Delivery</dt><dd>{type === "delivery" ? money(fee) : "Free"}</dd></div>
          <div className="flex justify-between border-t border-white/10 pt-3 font-heading text-lg font-semibold text-white"><dt>Total</dt><dd className="text-ember">{money(total)}</dd></div></dl>
        <div className="mt-6 space-y-3">
          {step === 0 && <button className="btn btn-primary w-full" onClick={() => setStep(1)}>Continue</button>}
          {step === 1 && <button className="btn btn-primary w-full" disabled={!valid} onClick={() => setStep(2)}>Review order</button>}
          {step === 2 && <button className="btn btn-primary w-full" disabled={state.loading} onClick={confirm}>{state.loading ? "Placing order..." : "Confirm order"}</button>}
          {step > 0 && <button className="btn btn-ghost w-full" onClick={() => setStep(step - 1)}>Back</button>}
          <a href={waLink(message())} target="_blank" rel="noopener noreferrer" className="btn w-full bg-[#25D366] text-white hover:brightness-110">Order on WhatsApp</a>
        </div>
      </aside>
    </div>
  );
}
