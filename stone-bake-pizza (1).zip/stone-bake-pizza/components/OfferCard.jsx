import Link from "next/link";
import { money, waLink } from "@/lib/site";
export default function OfferCard({ o }) {
  return (
    <article className="relative flex h-full flex-col overflow-hidden rounded-[2rem] bg-gradient-to-br from-ember to-[#b3380a] p-7 text-white">
      <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/10" />
      <span className="w-fit rounded-full bg-ink/30 px-3 py-1 text-xs font-semibold">{o.badge}</span>
      <h3 className="mt-5 text-2xl font-bold">{o.title}</h3>
      <p className="mt-2 flex-1 text-white/85">{o.items}</p>
      <p className="mt-1 text-sm text-white/70">{o.note}</p>
      <div className="mt-6 flex items-end justify-between">
        <div><p className="text-sm text-white/60 line-through">{money(o.was)}</p><p className="font-heading text-3xl font-bold">{money(o.price)}</p></div>
        <a href={waLink(`Hi, I'd like to order the ${o.title} (${money(o.price)}).`)} target="_blank" rel="noopener noreferrer" className="btn bg-ink text-white hover:bg-white hover:text-ink">Claim deal</a>
      </div>
    </article>
  );
}
