"use client";
import { createContext, useContext, useEffect, useReducer, useState } from "react";
import { site } from "@/lib/site";

const Ctx = createContext(null);
function reducer(state, a) {
  switch (a.type) {
    case "load": return a.items;
    case "add": {
      const f = state.find((i) => i.id === a.item.id);
      return f ? state.map((i) => (i.id === a.item.id ? { ...i, qty: i.qty + 1 } : i)) : [...state, { ...a.item, qty: 1 }];
    }
    case "qty": return state.map((i) => (i.id === a.id ? { ...i, qty: i.qty + a.d } : i)).filter((i) => i.qty > 0);
    case "remove": return state.filter((i) => i.id !== a.id);
    case "clear": return [];
    default: return state;
  }
}
export function CartProvider({ children }) {
  const [items, dispatch] = useReducer(reducer, []);
  const [toast, setToast] = useState("");
  useEffect(() => { try { const s = localStorage.getItem("sb-cart"); if (s) dispatch({ type: "load", items: JSON.parse(s) }); } catch {} }, []);
  useEffect(() => { try { localStorage.setItem("sb-cart", JSON.stringify(items)); } catch {} }, [items]);
  const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);
  const count = items.reduce((s, i) => s + i.qty, 0);
  const add = (item) => { dispatch({ type: "add", item: { id: item.id, name: item.name, price: item.price, image: item.image } }); setToast(`${item.name} added`); setTimeout(() => setToast(""), 1800); };
  return (
    <Ctx.Provider value={{ items, add, dispatch, subtotal, count, deliveryFee: site.deliveryFee }}>
      {children}
      <div aria-live="polite" className={`fixed bottom-24 left-1/2 z-50 -translate-x-1/2 rounded-full bg-cream px-5 py-2.5 text-sm font-medium text-ink shadow-xl transition-all duration-300 ${toast ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-4 opacity-0"}`}>{toast}</div>
    </Ctx.Provider>
  );
}
export const useCart = () => useContext(Ctx);
