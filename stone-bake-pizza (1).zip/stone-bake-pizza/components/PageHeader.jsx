import Image from "next/image";
import Reveal from "./Reveal";
export default function PageHeader({ title, text, image }) {
  return (
    <section className="relative isolate overflow-hidden pb-16 pt-36 sm:pb-20 sm:pt-44">
      {image && <Image src={image} alt="" fill priority sizes="100vw" className="-z-20 object-cover opacity-40" />}
      <div className="absolute inset-0 -z-10 bg-gradient-to-b from-ink/70 via-ink/80 to-ink" />
      <div className="container-x"><Reveal><h1 className="max-w-3xl text-4xl font-bold leading-tight sm:text-6xl">{title}</h1>{text && <p className="mt-5 max-w-xl text-lg text-white/70">{text}</p>}</Reveal></div>
    </section>
  );
}
