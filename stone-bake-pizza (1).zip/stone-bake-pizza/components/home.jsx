import Image from "next/image";
import Link from "next/link";
import Reveal from "./Reveal";
import MenuCard from "./MenuCard";
import ReviewCard from "./ReviewCard";
import OfferCard from "./OfferCard";
import { reasons } from "@/lib/data";
import { img } from "@/lib/images";
import { site } from "@/lib/site";

export function Featured({ items }) {
  return (
    <section className="section"><div className="container-x">
      <Reveal className="flex flex-wrap items-end justify-between gap-4"><div><h2 className="text-3xl font-bold sm:text-5xl">Straight from the stone</h2><p className="mt-3 max-w-md text-white/60">The dishes our regulars order again and again.</p></div><Link href="/menu" className="btn btn-ghost">See full menu</Link></Reveal>
      <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{items.slice(0, 6).map((m, i) => <Reveal key={m.id} delay={i * 0.06}><MenuCard item={m} /></Reveal>)}</div>
    </div></section>
  );
}
export function WhyUs() {
  return (
    <section className="section bg-char"><div className="container-x grid items-center gap-14 lg:grid-cols-2">
      <Reveal className="relative aspect-[4/5] overflow-hidden rounded-[2rem]"><Image src={img.oven} alt="Pizza baking on a stone" fill sizes="(min-width:1024px) 50vw, 100vw" className="object-cover" /></Reveal>
      <div><Reveal><h2 className="text-3xl font-bold sm:text-5xl">Why people drive to Dina for our pizza</h2></Reveal>
        <dl className="mt-10 grid gap-8 sm:grid-cols-2">{reasons.map((r, i) => <Reveal key={r.t} delay={i * 0.08}><dt className="border-l-2 border-ember pl-4 font-heading text-lg font-semibold text-white">{r.t}</dt><dd className="mt-2 pl-4 text-white/60">{r.d}</dd></Reveal>)}</dl></div>
    </div></section>
  );
}
export function ReviewsPreview({ items }) {
  return (
    <section className="section"><div className="container-x">
      <Reveal className="flex flex-wrap items-end justify-between gap-4"><h2 className="text-3xl font-bold sm:text-5xl">Loved by our neighbours</h2><Link href="/reviews" className="btn btn-ghost">Read all reviews</Link></Reveal>
      <div className="mt-12 grid gap-6 md:grid-cols-3">{items.slice(0, 3).map((r, i) => <Reveal key={r.name} delay={i * 0.08}><ReviewCard r={r} /></Reveal>)}</div>
    </div></section>
  );
}
export function OffersPreview({ items }) {
  return (
    <section className="section bg-char"><div className="container-x">
      <Reveal className="flex flex-wrap items-end justify-between gap-4"><div><h2 className="text-3xl font-bold sm:text-5xl">Deals worth sharing</h2><p className="mt-3 text-white/60">Save more when you order together.</p></div><Link href="/offers" className="btn btn-ghost">All offers</Link></Reveal>
      <div className="mt-12 grid gap-6 md:grid-cols-2">{items.slice(0, 2).map((o, i) => <Reveal key={o.id} delay={i * 0.1}><OfferCard o={o} /></Reveal>)}</div>
    </div></section>
  );
}
export function LocationSection() {
  return (
    <section className="section"><div className="container-x grid gap-10 lg:grid-cols-2">
      <Reveal><h2 className="text-3xl font-bold sm:text-5xl">Come hungry. We are in Dina.</h2>
        <p className="mt-5 text-white/65">{site.address}</p>
        <ul className="mt-6 space-y-2 text-white/70">{site.hours.map(([d, h]) => <li key={d} className="flex max-w-sm justify-between border-b border-white/10 pb-2"><span>{d}</span><span className="text-white">{h}</span></li>)}</ul>
        <div className="mt-8 flex flex-wrap gap-4"><a href={`tel:${site.phone.replace(/-/g, "")}`} className="btn btn-primary">Call {site.phone}</a><Link href="/contact" className="btn btn-ghost">Get directions</Link></div></Reveal>
      <Reveal delay={0.1}><div className="h-80 overflow-hidden rounded-[2rem] ring-1 ring-white/10 lg:h-full lg:min-h-96"><MapEmbed /></div></Reveal>
    </div></section>
  );
}
export function MapEmbed() {
  return <iframe title="Stone Bake Pizza location in Dina, Jhelum" src="https://www.google.com/maps?q=Dina,+Jhelum,+Pakistan&output=embed" className="h-full w-full border-0 grayscale invert-[.92] contrast-[.9]" loading="lazy" referrerPolicy="no-referrer-when-downgrade" />;
}
