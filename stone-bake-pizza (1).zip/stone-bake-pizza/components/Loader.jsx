"use client";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
export default function Loader() {
  const [show, setShow] = useState(true);
  useEffect(() => { const t = setTimeout(() => setShow(false), 1300); return () => clearTimeout(t); }, []);
  return (
    <AnimatePresence>
      {show && (
        <motion.div exit={{ opacity: 0 }} transition={{ duration: 0.6 }} className="fixed inset-0 z-[100] grid place-items-center bg-ink" role="status" aria-label="Loading">
          <div className="text-center">
            <svg viewBox="0 0 100 100" className="mx-auto h-20 w-20 animate-spin" style={{ animationDuration: "1.6s" }}>
              <circle cx="50" cy="50" r="44" fill="#E85D04" /><circle cx="50" cy="50" r="36" fill="#f6b45d" />
              {[[50, 28], [68, 44], [60, 68], [36, 66], [30, 44]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r="6" fill="#b3261e" />)}
              <path d="M50 50 L50 6 A44 44 0 0 1 94 50 Z" fill="#111" opacity=".85" />
            </svg>
            <p className="mt-5 font-heading text-lg font-semibold text-white">Stone Bake Pizza</p>
            <p className="text-sm text-white/50">Firing up the oven</p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
