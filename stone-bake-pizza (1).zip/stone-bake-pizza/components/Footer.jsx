import Link from "next/link";
import { site, nav } from "@/lib/site";
const Icon = ({ d }) => <svg viewBox="0 0 24 24" className="h-5 w-5 fill-current"><path d={d} /></svg>;
const socials = [
  ["Facebook", site.social.facebook, "M13.5 22v-8h2.700l.5-3.300h-3.200V8.600c0-.9.400-1.700 1.800-1.700h1.500V4.100S15.500 3.900 14.300 3.900c-2.500 0-4.100 1.500-4.100 4.200v2.600H7.500V14h2.700v8z"],
  ["Instagram", site.social.instagram, "M12 7.500A4.500 4.500 0 1 0 12 16.500 4.500 4.500 0 0 0 12 7.500zm0 7.400A2.900 2.900 0 1 1 12 9.100a2.900 2.900 0 0 1 0 5.800zM17 5.800a1 1 0 1 0 0 2 1 1 0 0 0 0-2zM12 3c-2.700 0-3 0-4.100.1C5.200 3.200 3.200 5.200 3.100 7.900 3 9 3 9.300 3 12s0 3 .1 4.100c.1 2.700 2.100 4.700 4.800 4.800C9 21 9.300 21 12 21s3 0 4.100-.1c2.700-.1 4.700-2.100 4.800-4.800.1-1.100.1-1.400.1-4.100s0-3-.1-4.100c-.1-2.700-2.100-4.700-4.800-4.800C15 3 14.700 3 12 3zm0 1.800c2.600 0 3 0 4 .1 1.700.1 2.500.9 2.600 2.600.1 1 .1 1.400.1 4s0 3-.1 4c-.1 1.700-.9 2.500-2.600 2.600-1 .1-1.400.1-4 .1s-3 0-4-.1c-1.700-.1-2.500-.9-2.600-2.600-.1-1-.1-1.400-.1-4s0-3 .1-4C5.500 5.700 6.300 4.900 8 4.900c1-.1 1.400-.1 4-.1z"],
  ["TikTok", site.social.tiktok, "M16.600 3h-3v12.500a2.500 2.500 0 1 1-2.500-2.500c.3 0 .5 0 .8.100V10a5.600 5.600 0 1 0 4.700 5.500V9a6.500 6.500 0 0 0 3.800 1.200V7.200A3.800 3.800 0 0 1 16.600 3z"],
];
export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-char">
      <div className="container-x grid gap-12 py-16 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <p className="font-heading text-2xl font-bold text-white">Stone<span className="text-ember"> Bake</span> Pizza</p>
          <p className="mt-4 max-w-sm text-white/60">Stone-baked pizza, burgers and fast food, made fresh every day in Dina, Jhelum.</p>
          <div className="mt-6 flex gap-3">{socials.map(([n, h, d]) => <a key={n} href={h} target="_blank" rel="noopener noreferrer" aria-label={n} className="grid h-10 w-10 place-items-center rounded-full border border-white/15 text-white/70 transition hover:border-ember hover:text-ember"><Icon d={d} /></a>)}</div>
        </div>
        <div><h3 className="font-heading text-base font-semibold">Explore</h3><ul className="mt-4 space-y-2 text-white/60">{nav.map(([l, h]) => <li key={h}><Link href={h} className="hover:text-ember">{l}</Link></li>)}</ul></div>
        <div><h3 className="font-heading text-base font-semibold">Visit or call</h3>
          <address className="mt-4 space-y-2 not-italic text-white/60"><p>{site.address}</p><p><a href={`tel:${site.phone.replace(/-/g, "")}`} className="hover:text-ember">{site.phone}</a></p><p className="pt-2 text-sm">Daily from noon until late.</p></address></div>
      </div>
      <div className="border-t border-white/10 py-5 text-center text-sm text-white/40">© {new Date().getFullYear()} Stone Bake Pizza. All rights reserved.</div>
    </footer>
  );
}
