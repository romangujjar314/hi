"use client";
import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { img } from "@/lib/images";

const words = "Freshly Baked Pizza, Crafted With Passion".split(" ");
export default function Hero() {
  return (
    <section className="relative isolate flex min-h-screen items-center overflow-hidden">
      <motion.div className="absolute inset-0 -z-20" initial={{ scale: 1.12 }} animate={{ scale: 1 }} transition={{ duration: 3, ease: "easeOut" }}>
        <Image src={img.hero} alt="Fresh stone baked pizza" fill priority sizes="100vw" className="object-cover" />
      </motion.div>
      <div className="absolute inset-0 -z-10 bg-gradient-to-r from-ink via-ink/75 to-ink/20" />
      <div className="absolute inset-x-0 bottom-0 -z-10 h-48 bg-gradient-to-t from-ink to-transparent" />
      <div className="absolute -bottom-40 -left-40 -z-10 h-[34rem] w-[34rem] animate-glow rounded-full bg-ember/30 blur-[120px]" />
      <div className="container-x pb-10 pt-28">
        <h1 className="max-w-3xl text-[2.6rem] font-bold leading-[1.05] sm:text-6xl lg:text-7xl" aria-label={words.join(" ")}>
          {words.map((w, i) => (
            <span key={i} className="mr-[.25em] inline-block overflow-hidden align-bottom"><motion.span className="inline-block" initial={{ y: "110%" }} animate={{ y: 0 }} transition={{ delay: 1.2 + i * 0.09, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}>{w}</motion.span></span>
          ))}
        </h1>
        <motion.p initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 2, duration: 0.7 }} className="mt-6 max-w-xl text-lg text-white/75">
          Experience delicious stone-baked pizzas, burgers and fast food prepared with fresh ingredients.
        </motion.p>
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 2.2, duration: 0.7 }} className="mt-9 flex flex-wrap gap-4">
          <Link href="/order" className="btn btn-primary">Order Now</Link>
          <Link href="/menu" className="btn btn-ghost">View Menu</Link>
        </motion.div>
      </div>
      <div className="absolute bottom-10 right-8 hidden h-36 w-36 lg:block" aria-hidden>
        <svg viewBox="0 0 120 120" className="h-full w-full animate-spinslow"><defs><path id="c" d="M60 60 m-44 0 a44 44 0 1 1 88 0 a44 44 0 1 1 -88 0" /></defs>
          <text className="fill-cream/80 font-heading text-[11px] font-medium" letterSpacing="2.600"><textPath href="#c">BAKED ON REAL STONE • FRESH DOUGH DAILY • </textPath></text></svg>
        <span className="absolute inset-0 grid place-items-center font-heading text-2xl font-bold text-ember">SB</span>
      </div>
    </section>
  );
}
