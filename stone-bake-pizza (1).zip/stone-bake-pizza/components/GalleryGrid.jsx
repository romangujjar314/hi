"use client";
import Image from "next/image";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
export default function GalleryGrid({ items }) {
  const cats = ["All", ...new Set(items.map((i) => i.cat))];
  const [cat, setCat] = useState("All");
  const [active, setActive] = useState(null);
  const shown = cat === "All" ? items : items.filter((i) => i.cat === cat);
  return (
    <>
      <div className="mb-8 flex flex-wrap gap-2">{cats.map((c) => <button key={c} onClick={() => setCat(c)} className={`rounded-full px-5 py-2 text-sm font-medium transition ${cat === c ? "bg-ember text-white" : "bg-white/5 text-white/70 hover:bg-white/10"}`}>{c}</button>)}</div>
      <div className="columns-1 gap-4 sm:columns-2 lg:columns-3 [&>*]:mb-4">
        {shown.map((g, i) => (
          <button key={g.src} onClick={() => setActive(g)} className="group relative block w-full overflow-hidden rounded-2xl">
            <Image src={g.src} alt={g.alt} width={900} height={i % 3 === 0 ? 1100 : 700} sizes="(min-width:1024px) 33vw, (min-width:640px) 50vw, 100vw" className="h-auto w-full object-cover transition duration-700 group-hover:scale-105" />
            <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/90 to-transparent p-4 text-left text-sm text-white opacity-0 transition group-hover:opacity-100">{g.alt}</span>
          </button>
        ))}
      </div>
      <AnimatePresence>
        {active && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setActive(null)} className="fixed inset-0 z-[60] grid cursor-zoom-out place-items-center bg-black/90 p-4" role="dialog" aria-label={active.alt}>
            <Image src={active.src} alt={active.alt} width={1400} height={1000} className="max-h-[85vh] w-auto rounded-2xl object-contain" />
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
