export default function Stars({ n = 5 }) {
  return <div className="flex gap-0.5" role="img" aria-label={`${n} out of 5 stars`}>{[1, 2, 3, 4, 5].map((i) => <svg key={i} viewBox="0 0 20 20" className={`h-4 w-4 ${i <= n ? "fill-[#FBBC04]" : "fill-white/15"}`}><path d="M10 1.500l2.600 5.400 5.900.8-4.300 4.100 1 5.800L10 14.800l-5.200 2.800 1-5.800L1.500 7.700l5.900-.8z" /></svg>)}</div>;
}
