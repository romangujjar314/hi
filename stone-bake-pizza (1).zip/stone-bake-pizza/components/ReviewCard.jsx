import Stars from "./Stars";
export default function ReviewCard({ r }) {
  return (
    <figure className="flex h-full flex-col rounded-2xl bg-white p-6 text-ink">
      <div className="flex items-center gap-3">
        <span className="grid h-11 w-11 place-items-center rounded-full bg-ember font-heading font-semibold text-white">{r.name[0]}</span>
        <div className="leading-tight"><figcaption className="font-heading font-semibold">{r.name}</figcaption><span className="text-xs text-ink/50">{r.when} · Google review</span></div>
      </div>
      <div className="mt-4"><Stars n={r.rating} /></div>
      <blockquote className="mt-3 text-[15px] leading-relaxed text-ink/75">{r.text}</blockquote>
    </figure>
  );
}
