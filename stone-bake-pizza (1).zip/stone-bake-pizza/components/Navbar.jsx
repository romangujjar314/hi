"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { nav } from "@/lib/site";
import { useCart } from "./CartProvider";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const path = usePathname();
  const { count } = useCart();
  useEffect(() => { const f = () => setScrolled(window.scrollY > 24); f(); window.addEventListener("scroll", f, { passive: true }); return () => window.removeEventListener("scroll", f); }, []);
  useEffect(() => setOpen(false), [path]);
  return (
    <header className={`fixed inset-x-0 top-0 z-40 transition duration-300 ${scrolled || open ? "bg-ink/90 backdrop-blur-lg shadow-[0_1px_0_rgba(255,255,255,.08)]" : "bg-transparent"}`}>
      <div className="container-x flex h-[72px] items-center justify-between">
        <Link href="/" className="font-heading text-xl font-bold text-white">Stone<span className="text-ember"> Bake</span></Link>
        <nav aria-label="Main" className="hidden items-center gap-7 lg:flex">
          {nav.map(([l, h]) => (
            <Link key={h} href={h} className={`relative text-sm font-medium transition hover:text-white ${path === h ? "text-white" : "text-white/65"}`}>
              {l}{path === h && <motion.span layoutId="nav-dot" className="absolute -bottom-2 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-ember" />}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <Link href="/order" className="btn btn-primary !px-5 !py-2.5">Order{count > 0 && <span className="grid h-5 min-w-5 place-items-center rounded-full bg-white px-1 text-xs text-ember">{count}</span>}</Link>
          <button className="grid h-10 w-10 place-items-center rounded-full border border-white/20 text-white lg:hidden" onClick={() => setOpen(!open)} aria-expanded={open} aria-label="Toggle menu">
            <span className="relative block h-3 w-5"><span className={`absolute left-0 h-0.5 w-5 bg-white transition ${open ? "top-1.5 rotate-45" : "top-0"}`} /><span className={`absolute left-0 top-1.5 h-0.5 w-5 bg-white transition ${open ? "opacity-0" : ""}`} /><span className={`absolute left-0 h-0.5 w-5 bg-white transition ${open ? "top-1.5 -rotate-45" : "top-3"}`} /></span>
          </button>
        </div>
      </div>
      <AnimatePresence>
        {open && (
          <motion.nav aria-label="Mobile" initial={{ height: 0 }} animate={{ height: "auto" }} exit={{ height: 0 }} className="overflow-hidden lg:hidden">
            <ul className="container-x pb-6">
              {nav.map(([l, h], i) => (
                <motion.li key={h} initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.04 }}>
                  <Link href={h} className={`block border-b border-white/10 py-3.5 font-heading text-lg ${path === h ? "text-ember" : "text-white"}`}>{l}</Link>
                </motion.li>
              ))}
            </ul>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
