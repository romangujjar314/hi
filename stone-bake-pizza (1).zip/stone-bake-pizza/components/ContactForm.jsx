"use client";
import { useState } from "react";
import { waLink } from "@/lib/site";
export default function ContactForm() {
  const [f, setF] = useState({ name: "", phone: "", message: "" });
  const [sent, setSent] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const submit = (e) => { e.preventDefault(); /* TODO: POST /api/contact */ window.open(waLink(`Hi, I'm ${f.name} (${f.phone}). ${f.message}`), "_blank"); setSent(true); };
  if (sent) return <div className="rounded-3xl bg-char p-8 ring-1 ring-white/10"><h3 className="text-xl font-bold">Message ready</h3><p className="mt-2 text-white/65">WhatsApp opened with your message. Press send there and we will reply soon.</p></div>;
  return (
    <form onSubmit={submit} className="space-y-4 rounded-3xl bg-char p-6 ring-1 ring-white/10 sm:p-8">
      <label className="block text-sm">Name<input required className="field mt-1.5" value={f.name} onChange={set("name")} /></label>
      <label className="block text-sm">Phone<input required type="tel" className="field mt-1.5" value={f.phone} onChange={set("phone")} /></label>
      <label className="block text-sm">Message<textarea required rows={4} className="field mt-1.5" value={f.message} onChange={set("message")} /></label>
      <button className="btn btn-primary w-full">Send message</button>
    </form>
  );
}
