"use client";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import MenuCard from "./MenuCard";
export default function MenuExplorer({ items, categories }) {
  const [cat, setCat] = useState("All");
  const shown = cat === "All" ? items : items.filter((i) => i.category === cat);
  return (
    <>
      <div className="sticky top-[72px] z-30 -mx-5 overflow-x-auto bg-ink/90 px-5 py-4 backdrop-blur sm:mx-0 sm:px-0" role="tablist">
        <div className="flex gap-2">
          {["All", ...categories].map((c) => (
            <button key={c} role="tab" aria-selected={cat === c} onClick={() => setCat(c)}
              className={`relative whitespace-nowrap rounded-full px-5 py-2.5 font-heading text-sm font-medium transition ${cat === c ? "text-white" : "text-white/60 hover:text-white"}`}>
              {cat === c && <motion.span layoutId="cat-pill" className="absolute inset-0 rounded-full bg-ember" />}
              <span className="relative">{c}</span>
            </button>
          ))}
        </div>
      </div>
      <motion.div layout className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <AnimatePresence mode="popLayout">
          {shown.map((i) => (
            <motion.div layout key={i.id} initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.96 }} transition={{ duration: 0.35 }}>
              <MenuCard item={i} />
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>
    </>
  );
}
