# Admin-ready structure
- `lib/data.js`  seed data (menu, offers, reviews, gallery) -> becomes DB tables.
- `lib/repo.js`  the only place pages read/write data. Replace with Prisma/Drizzle/Supabase calls.
- `app/api/orders/route.js` order intake. Add GET/PATCH (status) behind auth for order management.
- Add later: `app/admin/*` (dashboard, menu CRUD, orders), `app/api/menu/route.js`, auth via NextAuth/Clerk, and `middleware.js` to protect `/admin`.
- Suggested tables: menu_items, categories, offers, orders, order_items, reviews, gallery.
