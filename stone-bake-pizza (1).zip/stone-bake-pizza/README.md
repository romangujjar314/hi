# Stone Bake Pizza
```
npm install
npm run dev     # http://localhost:3000
npm run build && npm start
```
Images load from Unsplash (see `lib/images.js`); replace with your own photos in `/public` before launch.
Reviews, prices, hours and offers are sample content in `lib/data.js` and `lib/site.js`. Update with real details.
See ADMIN-READY.md for backend plans.
